package com.LeadDevelopments.Tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.LeadDevelopments.Utility.Constants;
import com.LeapDevelopments.PageObjects.CafeTownsend_HomePage;
import com.LeapDevelopments.PageObjects.CafeTownsend_LoginPage;

public class EditEmployeeDetailsTest {
WebDriver driver=null;
	
	@BeforeClass
	public void beforeClass() throws Throwable{  		         
		driver = new FirefoxDriver();  	  	
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);  	  
		driver.manage().window().maximize();
		driver.get(Constants.URL);
		}
	
	@Test
	public void editEmployeeRecord() throws Throwable{
		CafeTownsend_LoginPage.submitLoginCredentials(driver);
		CafeTownsend_HomePage.editEmpRecord(driver);
	}
	
	@AfterClass
	public void afterClass() throws Throwable {
		CafeTownsend_HomePage.PageLogout(driver);
		driver.close();
	}
}
