package com.LeadDevelopments.Utility;

public class Constants {
	public static final String URL= "http://cafetownsend-angular-rails.herokuapp.com/login";
	public static final String Username="Luke";
	public static final String Password="Skywalker";
	public static final String EmpFirstName="User";
	public static final String EmpLastName="Dev";
	public static final String EmpupdateLName="Development";
	public static final String JoinDate="2016-10-03";
	public static final String Email=EmpFirstName+"."+EmpLastName+"@leapdev.com.au";
	public static final String WelcomeMessage="Hello Luke";
	
}
