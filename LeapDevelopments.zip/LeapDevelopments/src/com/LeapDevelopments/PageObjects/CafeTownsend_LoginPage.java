package com.LeapDevelopments.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.LeadDevelopments.Utility.Constants;

public class CafeTownsend_LoginPage {
		// Getting objects from Login Page
	    private static By UsernameInput = By.xpath("//*[@id='login-form']/fieldset/label[1]/input");
	    private static By PasswordInput = By.xpath("//*[@id='login-form']/fieldset/label[2]/input");
	    private static By loginSubmitBtn = By.xpath("//*[@id='login-form']/fieldset/button");
	    private static By welcomemsg =     By.id("greetings");

	   // Populate User Name
	    private static void enterUserLogin(WebDriver driver) {
	        WebElement Username = driver.findElement(UsernameInput);
	        Username.sendKeys(Constants.Username);
	   }
	    
	    //Populate Password
	    private static void enterUserPassword(WebDriver driver) {
	        WebElement password = driver.findElement(PasswordInput);
	        password.sendKeys(Constants.Password);	        
	    }
	    
	    //Click on Login & verify that Home page is displayed
	    public static void submitLoginCredentials(WebDriver driver) {
	    	CafeTownsend_LoginPage.enterUserLogin(driver);
	    	CafeTownsend_LoginPage.enterUserPassword(driver);
	    	WebElement Submitbtn=driver.findElement(loginSubmitBtn);
	    	Submitbtn.click();
	    	try{
	    		WebElement Welcome=driver.findElement(welcomemsg);
	    		if(Welcome.getText()== Constants.WelcomeMessage)
	    		{
	    			System.out.println("User Logged in successfully");
	    		}
	    	}
	    	catch(Exception e){
	    	System.out.println("Login Failed"+ e);	
	    	}
	    	
	    }
	}

