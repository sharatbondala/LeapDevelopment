package com.LeapDevelopments.PageObjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.LeadDevelopments.Utility.Constants;

public class CafeTownsend_HomePage {
	private static By CreateBtn = 	   By.id("bAdd");
    private static By EditBtn   =      By.id("bEdit");
    private static By DeleteBtn =      By.id("bDelete");
    private static By FirstNameInput = By.xpath("//form[@name='employeeForm']/fieldset/label[1]/input");
    private static By LastNameInput =  By.xpath("//form[@name='employeeForm']/fieldset/label[2]/input");
    private static By StartDateInput = By.xpath("//form[@name='employeeForm']/fieldset/label[3]/input");
    private static By EmailInput =     By.xpath("//form[@name='employeeForm']/fieldset/label[4]/input");
    private static By EmpRec =		   By.xpath("//li[contains(text(), '" + Constants.EmpFirstName+" "+Constants.EmpLastName+"')]");
    private static By EmpUpdateRec =   By.xpath("//li[contains(text(), '" + Constants.EmpFirstName+" "+Constants.EmpupdateLName+"')]");
    private static By LogoutBtn =	   By.xpath(".//div[@class='header-container']/p[1]");
    
   //Create a New Employee record
    public static void createNewEmpRecord(WebDriver driver) {
        WebElement CreateButton = driver.findElement(CreateBtn);
        CreateButton.click();
        
        WebElement FirstName = driver.findElement(FirstNameInput);
        FirstName.sendKeys(Constants.EmpFirstName);
        
        WebElement LastName = driver.findElement(LastNameInput);
        LastName.sendKeys(Constants.EmpLastName);
        
        WebElement StartDate = driver.findElement(StartDateInput);
        StartDate.sendKeys(Constants.JoinDate);
        
        WebElement Email = driver.findElement(EmailInput);
        Email.sendKeys(Constants.Email);
        
        Email.submit();
   }
    
    // Edit the details(Change Last name) of the Existing employee 
    public static void editEmpRecord(WebDriver driver)
    {
    	WebElement Employee=driver.findElement(EmpRec);
    	Employee.click();
    	
    	WebElement EditButton = driver.findElement(EditBtn);
    	EditButton.click();
    	
    	WebElement LastName = driver.findElement(LastNameInput);
        LastName.clear();
        LastName.sendKeys(Constants.EmpupdateLName);
        LastName.submit();
        
    }
    
    //Delete the employee which is created in previous test case 
    public static void deleteEmpRecord(WebDriver driver) throws InterruptedException {
    	WebElement Employee=driver.findElement(EmpUpdateRec);
    	Employee.click();
    	
    	WebElement DeleteButton = driver.findElement(DeleteBtn);
        DeleteButton.click();
        
        Thread.sleep(2000);
        Alert alert=driver.switchTo().alert();
		alert.accept();        
        
    }
    
    //Logout of the Page
    public static void PageLogout(WebDriver driver) {
    	
    	WebElement Logout =driver.findElement(LogoutBtn);
    	Logout.click();
    	
    }

  }
